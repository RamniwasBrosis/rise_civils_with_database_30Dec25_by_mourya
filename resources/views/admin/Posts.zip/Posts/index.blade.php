@extends('admin.layout.main')

@section('content')
<!DOCTYPE html>
<html>
<head>
    <title>RISE - An Institute For Civil Services</title>
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" />
    <link href="https://cdn.datatables.net/1.10.21/css/jquery.dataTables.min.css" rel="stylesheet">
    <link href="https://cdn.datatables.net/1.10.21/css/dataTables.bootstrap4.min.css" rel="stylesheet">
    <style>
        #myTable_processing {
            display: none;
        }
    </style>
</head>
<body>
    <br>
    <div class="container-fluid">
        <!-- Info boxes -->
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <div class="row">
                            <div class="col-md-8">
                                <h3 class="card-title">Page list</h3>
                            </div>
                            <div class="col-md-4 text-right">
                                <a href="{{ route('admin.addPosts') }}" style="margin-left:70%;" class="btn btn-info">Add
                                    More</a>
                            </div>
                        </div>
                    </div>
                    <div class="container mt-5">
                        <table id="myTable" class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Name</th>
                                    <th>Category</th>
                                    <th>Description</th>
                                    <th>Image</th>
                                    <th>Order No</th>
                                    <th>Status</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach ($posts as $post)
                                <tr>
                                    <td>{{ $loop->iteration }}</td>
                                    <td>{{ $post->name }}</td>
                                    <td>
                                        @php
                                            $categoryPath = '';
                                            $current = $post->category;
                                    
                                            // Traverse up the category tree until the parent is null
                                            while ($current) {
                                                $categoryPath = $current->name . ($categoryPath ? ' / ' . $categoryPath : '');
                                                
                                                // Crucially, check if the parent relationship has been loaded
                                                // Use the 'parent' relationship from the Category model
                                                $current = $current->parent;
                                            }
                                    
                                            echo $categoryPath ?: 'No Category';
                                        @endphp
                                    </td>
                                    <td>{{ $post->description }}</td>
                                    <td>
                                        @if($post->image)
                                            <img src="{{ asset($post->image) }}" width="100">
                                        @else
                                            <img src="{{ asset('assets_rise/img/no_image.jpg') }}" alt="No Image Available" width="100">
                                        @endif
                                    </td>
                                    <td>{{ $post->order_no ?? '-' }}</td>
                                    <td>
                                        @if($post->status == 1)
                                            <button class="btn btn-sm btn-success disabled">Active</button>
                                        @else
                                            <button class="btn btn-sm btn-danger disabled">Inactive</button>
                                        @endif
                                    </td>
                                    <td>
                                        <a class="badge badge-info border-0" href="{{ route('admin.editPosts', $post->id) }}">Edit</a>
                                        <form action="{{ route('tickets.delete', $post->id) }}" method="POST" style="display:inline;">
                                            @csrf
                                            @method('DELETE')
                                            <button type="submit" class="badge badge-danger light border-0" onclick="return confirm('Are you sure you want to delete this?')">
                                                Delete
                                            </button>
                                        </form>
                                    </td>
                                </tr>
                                @endforeach
                                </tbody>
                        </table>

                    </div>

                </div>

</body>

@endsection



@section('inlinescript')

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.0/jquery.validate.js"></script>

<script src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>

<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>

<script src="https://cdn.datatables.net/1.10.21/js/dataTables.bootstrap4.min.js"></script>

<script>
    $(document).on('change', '.ticket-check', function() {
        let ticketId = $(this).data('id');
        let isChecked = $(this).is(':checked') ? 1 : 0;

        $.ajax({
            url: "{{ route('admin.updateTicketCheck') }}", // route we'll create
            type: "POST",
            data: {
                id: ticketId,
                isChecked: isChecked,
                _token: "{{ csrf_token() }}"
            },
            success: function(response) {
                // console.log(response.message);
            },
            error: function(xhr) {
                alert('Error updating ticket status');
            }
        });
    });
</script>
<script>
    $(document).ready(function () {
        $('#myTable').DataTable({
            pageLength: 10,
            lengthMenu: [10, 25, 50, 100],
        });
    });
</script>


@endsection