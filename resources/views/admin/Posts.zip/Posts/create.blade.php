@extends('admin.layout.main')



@section('content')

<br>
<div class="container-fluid">
    <!-- Info boxes -->
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <div class="row">
                        <div class="col-md-8">
                            <h3 class="card-title">Pages</h3>
                        </div>
                        <div class="col-md-4 text-right">
                            <a href="{{ route('admin.posts') }}" style="margin-left:70%;" class="btn btn-info">Back</a>
                        </div>
                    </div>
                </div>
                <div class="container mt-3">
                    <form id="addUser" action="{{ route('admin.storePosts') }}" autocomplete="off" method="post" enctype="multipart/form-data">
                        @csrf
                        <div id="successMessage" style="color: green; margin-top: 15px;"></div>
                        <div class="form-group">
                            <label for="floatingfirst">Select Chapter:</label>
                            <!--<select class="form-control" name="category_id">-->
                            <!--    <option value="">Select</option>-->
                            <!--    @include('admin.categories.dropdown_options', [-->
                            <!--        'categories' => $categories,-->
                            <!--        'selected' => $post->category_id ?? null,-->
                            <!--        'prefix' => ''-->
                            <!--    ])-->
                            <!--</select>-->
                            
                            <select class="form-control" name="category_id">
                                <option value="">Select</option>
                                @foreach($chapters as $chapter)
                                <option value="{{$chapter->id}}">{{$chapter->name}}</option>
                                @endforeach
                            </select>

                        </div>

                        <div class="form-group">
                            <label for="floatingfirst">Page Name:</label>
                            <input type="text" class="form-control" name="name" placeholder="Post Name">
                            <span class="error" id="sub-category" style="color: red;"></span>
                        </div>
                        <div class="form-group">
                            <label>Description:</label>
                            <textarea name="description" class="form-control" rows="3"
                                placeholder="Short description..."></textarea>
                        </div>
                        
                        <div class="form-group">
                            <label>Content:</label>
                            <textarea id="editor" name="content" class="form-control"
                                placeholder="Write full content here..." rows="5"></textarea>
                        </div>

                        <div class="form-group">
                            <label for="cat_image">Image:</label>
                            <input type="file" class="form-control" name="image" placeholder="Category image">
                        </div>
                        <div class="form-group">
                            <label for="cat_image">Pdf:</label>
                            <input type="file" class="form-control" name="pdf" placeholder="Category pdf">
                        </div>
                        <div class="form-group">
                            <div class="form-check">
                                <input class="form-check-input" 
                                       type="checkbox" 
                                       name="pass_protected" 
                                       value="1" 
                                       id="pass_protected">
                                <label class="form-check-label" for="pass_protected">
                                    Password Protected
                                </label>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="cat_image">Order No:</label>
                            <input type="number" class="form-control" name="order_no" placeholder="Enter Order No">
                        </div>
                        <div class="form-group">
                            <label for="status">Status:</label>
                            <select name="status" class="form-control">
                                <option value="1" selected>Active</option>
                                <option value="0">Inactive</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <button type="submit" class="btn btn-info btn-lg">Save</button>
                        </div>
                    </form>

                </div>
            </div>

            @endsection



            @section('inlinescript')

            <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.js"></script>
            <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.0/jquery.validate.js"></script>
            <script src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>
            <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
            <script src="https://cdn.datatables.net/1.10.21/js/dataTables.bootstrap4.min.js"></script>
            <script>
                $(document).ready(function() {
                    $('#myTable').DataTable(); // No ajax needed
                });
            </script>
            <script src="https://cdn.ckeditor.com/ckeditor5/39.0.1/classic/ckeditor.js"></script>
            <script>
                // ClassicEditor.create(document.querySelector('#editor'))
                //     .catch(error => console.error(error));
                
                
                ClassicEditor.create(document.querySelector('#editor'), {
                    toolbar: [
                        'heading', '|', 'bold', 'italic', 'link', 'bulletedList', 'numberedList', '|',
                        'insertTable', 'uploadImage', 'blockQuote', 'undo', 'redo'
                    ],
                    ckfinder: {
                        uploadUrl: '/store-posts' // your upload route
                    },
                    image: {
                        toolbar: [
                            'imageTextAlternative', 'imageStyle:full', 'imageStyle:side', 'linkImage'
                        ]
                    }
                })
                .then(editor => {
                 
                    const editable = editor.ui.view.editable.element;
                    editable.style.minHeight = '300px';
                    editable.style.maxHeight = '600px';
                    editable.style.overflowY = 'auto';
                })
                .catch(error => console.error(error));
            </script>


            @endsection
