
<!DOCTYPE html>
<html class="no-js" lang="en">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="x-ua-compatible" content="ie=edge" />
        <title>RISE - An Institute For Civil Services</title>
        <script src="assets/js/vendor/color-modes.js"></script>
        <meta name="description" content="RISE - An Institute For Civil Services" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <link rel="shortcut icon" type="image/x-icon" href="{{ asset('assets_rise/img/favicon.png') }}" />
        <!-- Place favicon.ico in the root directory -->
        <!-- CSS here -->
        <link rel="stylesheet" href="{{ asset('assets_rise/css/bootstrap.min.css') }}" />
        <link rel="stylesheet" href="{{ asset('assets_rise/css/animate.min.css') }}" />
        <link rel="stylesheet" href="{{ asset('assets_rise/css/magnific-popup.css') }}" />
        <link rel="stylesheet" href="{{ asset('assets_rise/css/fontawesome-all.min.css') }}" />
        <link rel="stylesheet" href="{{ asset('assets_rise/css/flaticon.css') }}" />
        <link rel="stylesheet" href="{{ asset('assets_rise/css/odometer.css') }}" />
        <link rel="stylesheet" href="{{ asset('assets_rise/css/swiper-bundle.css') }}" />
        <link rel="stylesheet" href="{{ asset('assets_rise/css/aos.css') }}" />
        <link rel="stylesheet" href="{{ asset('assets_rise/css/default.css') }}" />
        <link rel="stylesheet" href="{{ asset('assets_rise/css/main.css') }}" />
    </head>
    <body>
        <!--Preloader-->
        <div id="preloader">
            <div id="loader" class="loader">
                <div class="loader-container">
                    <div class="loader-icon"><img src="{{ asset('assets_rise/img/logo/preloader.png') }}" alt="Preloader" /></div>
                </div>
            </div>
        </div>
        <!--Preloader-end -->
        <!-- Scroll-top -->
        <button class="scroll__top scroll-to-target" data-target="html">
            <i class="fas fa-angle-up"></i>
        </button>
        <!-- Scroll-top-end-->
        <!-- header-area -->
        <header class="tg-header__style-five">
            <div class="tg-header__top">
                <div class="container custom-container">
                    <div class="row">
                        <div class="col-lg-6">
                            <ul class="tg-header__top-info left-side list-wrap">
                                <li><i class="flaticon-phone-call"></i><a href="tel:9785606061">97856 06061</a></li>
                                <li><i class="flaticon-pin"></i>Under Triveni Puliya, 7A, Gangotri Nagar, Arjun Nagar, Jaipur</li>
                            </ul>
                        </div>
                        <div class="col-lg-6">
                            <ul class="tg-header__top-right list-wrap"> 
                                <li><a href="https://web.risecivils.com/login" class="btn-login">Login</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div id="sticky-header" class="tg-header__area tg-header__area-five">
                <div class="container">
                    <div class="row">
                        <div class="col-12">
                            <div class="tgmenu__wrap">
                                <nav class="tgmenu__nav">
                                    <div class="logo">
                                        <a href="index.html"><img src="{{ asset('assets_rise/img/logo/logo.png') }}" alt="Logo" /></a>
                                    </div>
                                    <div class="tgmenu__navbar-wrap tgmenu__main-menu d-none d-lg-flex">
                                        <ul class="navigation">
                                            <li class="active">
                                                <a href="#">Home</a> 
                                            </li>
                                            <li class="menu-item-has-children">
                                                <a href="/ras" >
                                                    RAS Prelims
                                                </a>
                                                <ul  class="sub-menu">
                                                    <li class="">
                                                        <a href="/prelims-course" >
                                                            Prelims Course
                                                        </a>
                                                    </li>
                                                    <li class="">
                                                        <a href="/prelims-test-series" >
                                                            Prelims Test Series
                                                        </a>
                                                    </li>
                                                    <li class="">
                                                        <a href="/prelims-study-material" >
                                                            Prelims Study Material
                                                        </a>
                                                    </li>
                                                </ul>
                                            </li>
                                            <li class="menu-item-has-children">
                                                <a href="/ras-mains-1" >
                                                   RAS Mains
                                                </a>
                                                <ul  class="sub-menu">
                                                    <li class="">
                                                        <a href="/mains-course" >
                                                            Mains Course
                                                        </a>
                                                    </li>
                                                    <li class="">
                                                        <a href="/mains-test-series" >
                                                            Mains Test Series
                                                        </a>
                                                    </li>
                                                    <li class="">
                                                        <a href="/mains-study-material" >
                                                            Mains Study Material
                                                        </a>
                                                    </li>
                                                </ul>
                                            </li>
                                            <li class="menu-item-has-children">
                                                <a href="/rsmssb-1" >
                                                    RSMSSB
                                                </a>
                                                <ul  class="sub-menu">
                                                    <li class="">
                                                        <a href="/lab-attendant" >
                                                            Lab Attendant
                                                        </a>
                                                    </li>
                                                    <li class="">
                                                        <a href="/patwar" >
                                                            Patwar
                                                        </a>
                                                    </li>
                                                    <li class="">
                                                        <a href="/vdo" >
                                                            VDO
                                                        </a>
                                                    </li>
                                                    <li class="">
                                                        <a href="/stenographer" >
                                                            Stenographer
                                                        </a>
                                                    </li>
                                                </ul>
                                            </li>
                                            <li class="menu-item-has-children">
                                                <a href="{{ route('admin.viewBlog') }}" >
                                                    Study Material
                                                </a>
                                                <ul  class="sub-menu">
                                                    <li class="menu-item-has-children">
                                                        <a href="/rajasthan-study-material" >
                                                            Rajasthan
                                                        </a>
                                                        <ul  class="sub-menu">
                                                            <li class="">
                                                                <a href="/rajasthan-history" >
                                                                    History
                                                                </a>
                                                            </li>
                                                            <li class="">
                                                                <a href="/rajasthan-political-science" >
                                                                    Political Science
                                                                </a>
                                                            </li>
                                                            <li class="">
                                                                <a href="/rajasthan-geography" >
                                                                    Geography
                                                                </a>
                                                            </li>
                                                            <li class="">
                                                                <a href="/rajasthan-economics" >
                                                                    Economics
                                                                </a>
                                                            </li>
                                                        </ul>
                                                    </li>
                                                    <li class="menu-item-has-children">
                                                        <a href="/india-study-material" >
                                                            India
                                                        </a>
                                                        <ul  class="sub-menu">
                                                            <li class="">
                                                                <a href="/indian-history" >
                                                                    History
                                                                </a>
                                                            </li>
                                                            <li class="">
                                                                <a href="/indian-political-science" >
                                                                    Political Science
                                                                </a>
                                                            </li>
                                                            <li class="">
                                                                <a href="/indian-geography" >
                                                                    Geography
                                                                </a>
                                                            </li>
                                                            <li class="">
                                                                <a href="/indian-economics" >
                                                                    Economics
                                                                </a>
                                                            </li>
                                                        </ul>
                                                    </li>
                                                    <li class="menu-item-has-children">
                                                        <a href="/world-history-index" >
                                                            World
                                                        </a>
                                                        <ul  class="sub-menu">
                                                            <li class="">
                                                                <a href="/world-history" >
                                                                    History
                                                                </a>
                                                            </li>
                                                            <li class="">
                                                                <a href="/world-political-science" >
                                                                    Political Science
                                                                </a>
                                                            </li>
                                                            <li class="">
                                                                <a href="/world-geography" >
                                                                    Geography
                                                                </a>
                                                            </li>
                                                            <li class="">
                                                                <a href="/world-economics" >
                                                                    Economics
                                                                </a>
                                                            </li>
                                                        </ul>
                                                    </li>
                                                    <li class="menu-item-has-children">
                                                        <a href="/other-study-material" >
                                                            Other States G.K.
                                                        </a>
                                                        <ul  class="sub-menu">
                                                            <li class="">
                                                                <a href="/other-history" >
                                                                    History
                                                                </a>
                                                            </li>
                                                            <li class="">
                                                                <a href="/other-political-science" >
                                                                    Political Science
                                                                </a>
                                                            </li>
                                                            <li class="">
                                                                <a href="/other-geography" >
                                                                    Geography
                                                                </a>
                                                            </li>
                                                            <li class="">
                                                                <a href="/other-economics" >
                                                                    Economics
                                                                </a>
                                                            </li>
                                                        </ul>
                                                    </li>
                                                </ul>
                                            </li>
                                            <li class="menu-item-has-children">
                                                <a href="/test-series-1" >
                                                    Test Series
                                                </a>
                                                <ul  class="sub-menu">
                                                    <li class="">
                                                        <a href="/ras-prelims" >
                                                            RAS Prelims
                                                        </a>
                                                    </li>                                                        
                                                    <li class="">
                                                        <a href="/ras-mains-2" >
                                                            RAS Mains
                                                        </a>
                                                    </li>            
                                                    <li class="">
                                                        <a href="/psi" >
                                                            PSI
                                                        </a>
                                                    </li>
                                                </ul>
                                            </li>
                                            <li class="">
                                                <a href="/booklets-1" >
                                                    Booklets
                                                </a>
                                            </li>                        
                                            <li class="">
                                                <a href="/current-affairs-1" >
                                                    Current Affairs
                                                </a>
                                            </li>
                                        </ul>
                                    </div> 
                                    <div class="mobile-nav-toggler mobile-nav-toggler-two">
                                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 18 18" fill="none">
                                            <path d="M0 2C0 0.895431 0.895431 0 2 0C3.10457 0 4 0.895431 4 2C4 3.10457 3.10457 4 2 4C0.895431 4 0 3.10457 0 2Z" fill="currentcolor" />
                                            <path d="M0 9C0 7.89543 0.895431 7 2 7C3.10457 7 4 7.89543 4 9C4 10.1046 3.10457 11 2 11C0.895431 11 0 10.1046 0 9Z" fill="currentcolor" />
                                            <path d="M0 16C0 14.8954 0.895431 14 2 14C3.10457 14 4 14.8954 4 16C4 17.1046 3.10457 18 2 18C0.895431 18 0 17.1046 0 16Z" fill="currentcolor" />
                                            <path d="M7 2C7 0.895431 7.89543 0 9 0C10.1046 0 11 0.895431 11 2C11 3.10457 10.1046 4 9 4C7.89543 4 7 3.10457 7 2Z" fill="currentcolor" />
                                            <path d="M7 9C7 7.89543 7.89543 7 9 7C10.1046 7 11 7.89543 11 9C11 10.1046 10.1046 11 9 11C7.89543 11 7 10.1046 7 9Z" fill="currentcolor" />
                                            <path d="M7 16C7 14.8954 7.89543 14 9 14C10.1046 14 11 14.8954 11 16C11 17.1046 10.1046 18 9 18C7.89543 18 7 17.1046 7 16Z" fill="currentcolor" />
                                            <path d="M14 2C14 0.895431 14.8954 0 16 0C17.1046 0 18 0.895431 18 2C18 3.10457 17.1046 4 16 4C14.8954 4 14 3.10457 14 2Z" fill="currentcolor" />
                                            <path d="M14 9C14 7.89543 14.8954 7 16 7C17.1046 7 18 7.89543 18 9C18 10.1046 17.1046 11 16 11C14.8954 11 14 10.1046 14 9Z" fill="currentcolor" />
                                            <path d="M14 16C14 14.8954 14.8954 14 16 14C17.1046 14 18 14.8954 18 16C18 17.1046 17.1046 18 16 18C14.8954 18 14 17.1046 14 16Z" fill="currentcolor" />
                                        </svg>
                                    </div>
                                </nav>
                            </div>
                            <!-- Mobile Menu  -->
                            <div class="tgmobile__menu">
                                <nav class="tgmobile__menu-box">
                                    <div class="close-btn"><i class="fas fa-times"></i></div>
                                    <div class="nav-logo">
                                        <a href="index.html"><img src="{{ asset('assets_rise/img/logo/logo.png') }}" alt="Logo" /></a>
                                    </div>
                                    <div class="tgmobile__search">
                                        <form action="#">
                                            <input type="text" placeholder="Search here..." />
                                            <button><i class="fas fa-search"></i></button>
                                        </form>
                                    </div>
                                    <div class="tgmobile__menu-outer">
                                        <!--Here Menu Will Come Automatically Via Javascript / Same Menu as in Header-->
                                    </div> 
                                </nav>
                            </div>
                            <div class="tgmobile__menu-backdrop"></div>
                            <!-- End Mobile Menu -->
                        </div>
                    </div>
                </div>
            </div>
        </header>
        <!-- header-area-end -->
        <style>
        .whatsico{position: fixed;
        right: 0;
        top: 20%;
        background: #25D366;
        z-index: 100;
        color: #fff;
        padding: 10px 10px 10px 12px;
        border-radius: 10px 0 0 10px;}
        .whatsico svg{fill: #fff;
        width: 30px;
        height: 30px;}  
        </style>
        <a href="https://wa.me/919785606061" target="_blank" class="whatsico"><svg fill="#000000" width="800px" height="800px" viewBox="-1.66 0 740.824 740.824" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" clip-rule="evenodd" d="M630.056 107.658C560.727 38.271 468.525.039 370.294 0 167.891 0 3.16 164.668 3.079 367.072c-.027 64.699 16.883 127.855 49.016 183.523L0 740.824l194.666-51.047c53.634 29.244 114.022 44.656 175.481 44.682h.151c202.382 0 367.128-164.689 367.21-367.094.039-98.088-38.121-190.32-107.452-259.707m-259.758 564.8h-.125c-54.766-.021-108.483-14.729-155.343-42.529l-11.146-6.613-115.516 30.293 30.834-112.592-7.258-11.543c-30.552-48.58-46.689-104.729-46.665-162.379C65.146 198.865 202.065 62 370.419 62c81.521.031 158.154 31.81 215.779 89.482s89.342 134.332 89.311 215.859c-.07 168.242-136.987 305.117-305.211 305.117m167.415-228.514c-9.176-4.591-54.286-26.782-62.697-29.843-8.41-3.061-14.526-4.591-20.644 4.592-6.116 9.182-23.7 29.843-29.054 35.964-5.351 6.122-10.703 6.888-19.879 2.296-9.175-4.591-38.739-14.276-73.786-45.526-27.275-24.32-45.691-54.36-51.043-63.542-5.352-9.183-.569-14.148 4.024-18.72 4.127-4.11 9.175-10.713 13.763-16.07 4.587-5.356 6.116-9.182 9.174-15.303 3.059-6.122 1.53-11.479-.764-16.07-2.294-4.591-20.643-49.739-28.29-68.104-7.447-17.886-15.012-15.466-20.644-15.746-5.346-.266-11.469-.323-17.585-.323-6.117 0-16.057 2.296-24.468 11.478-8.41 9.183-32.112 31.374-32.112 76.521s32.877 88.763 37.465 94.885c4.587 6.122 64.699 98.771 156.741 138.502 21.891 9.45 38.982 15.093 52.307 19.323 21.981 6.979 41.983 5.994 57.793 3.633 17.628-2.633 54.285-22.19 61.932-43.616 7.646-21.426 7.646-39.791 5.352-43.617-2.293-3.826-8.41-6.122-17.585-10.714"/></svg></a>
 
        <!-- main-area -->
        <main class="fix"> 
            <!-- blog-area -->
            <section class="blog__area">
                <div class="container">
                    <div class="blog__inner-wrap">
                        <div class="row">
                            <div class="col-70">
                                <div class="blog-post-wrap">
                                    <div class="row gutter-24">
                                        @forelse ($categories as $category)
                                            <div class="col-md-6">
                                                <div class="blog__post-two shine-animate-item">
                                                    
                                                    <div class="blog__post-thumb-two">
                                                        <a href="{{ route('category.blog', $category->id) }}" class="shine-animate">
                                                            <img src="{{ asset($category->cat_image ?? 'assets/default-cat.jpg') }}" 
                                                                 alt="{{ $category->name }}" 
                                                                 style="min-height: 300px; width: 100%; object-fit: cover;">
                                                        </a>
                                                    </div>
                                    
                                                    <div class="blog__post-content-two">
                                                        <h2 class="title">
                                                            <a href="{{ route('category.blog', $category->id) }}">
                                                                {{ $category->name }}
                                                            </a>
                                                        </h2>
                                                    </div>
                                                </div>
                                            </div>
                                        @empty
                                            <p class="text-center">No Subcategories Available</p>
                                        @endforelse
                                    </div>

                                    <div class="pagination-wrap mt-40">
                                        <nav aria-label="Page navigation example">
                                            <ul class="pagination list-wrap">
                                                <li class="page-item">
                                                    <a class="page-link" href="#"><i class="fas fa-angle-double-left"></i></a>
                                                </li>
                                                <li class="page-item active"><a class="page-link" href="#">1</a></li>
                                                <li class="page-item"><a class="page-link" href="#">2</a></li>
                                                <li class="page-item"><a class="page-link" href="#">3</a></li>
                                                <li class="page-item"><a class="page-link" href="#">4</a></li>
                                                <li class="page-item next-page">
                                                    <a class="page-link" href="#"><i class="fas fa-angle-double-right"></i></a>
                                                </li>
                                            </ul>
                                        </nav>
                                    </div>
                                </div>
                            </div>
                            <div class="col-30">
                                <aside class="blog__sidebar">
                                    <div class="sidebar__widget sidebar__widget-two">
                                        <div class="sidebar__search">
                                            <form action="#">
                                                <input type="text" placeholder="Search . . ." />
                                                <button type="submit">
                                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="none">
                                                        <path d="M19.0002 19.0002L14.6572 14.6572M14.6572 14.6572C15.4001 13.9143 15.9894 13.0324 16.3914 12.0618C16.7935 11.0911 17.0004 10.0508 17.0004 9.00021C17.0004 7.9496 16.7935 6.90929 16.3914 5.93866C15.9894 4.96803 15.4001 4.08609 14.6572 3.34321C13.9143 2.60032 13.0324 2.01103 12.0618 1.60898C11.0911 1.20693 10.0508 1 9.00021 1C7.9496 1 6.90929 1.20693 5.93866 1.60898C4.96803 2.01103 4.08609 2.60032 3.34321 3.34321C1.84288 4.84354 1 6.87842 1 9.00021C1 11.122 1.84288 13.1569 3.34321 14.6572C4.84354 16.1575 6.87842 17.0004 9.00021 17.0004C11.122 17.0004 13.1569 16.1575 14.6572 14.6572Z" stroke="currentcolor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                                                    </svg>
                                                </button>
                                            </form>
                                        </div>
                                    </div>
                                    <div class="sidebar__widget">
                                        <h4 class="sidebar__widget-title">Categories</h4>
                                        <div class="sidebar__cat-list">
                                            <ul class="list-wrap">
                                                <li>
                                                    <a href="#"><i class="flaticon-arrow-button"></i>Business Solution (15)</a>
                                                </li>
                                                <li>
                                                    <a href="#"><i class="flaticon-arrow-button"></i>Marketing Planning (11)</a>
                                                </li>
                                                <li>
                                                    <a href="#"><i class="flaticon-arrow-button"></i>SEO Consulting (05)</a>
                                                </li>
                                                <li>
                                                    <a href="#"><i class="flaticon-arrow-button"></i>Project Management (07)</a>
                                                </li>
                                                <li>
                                                    <a href="#"><i class="flaticon-arrow-button"></i>Business Development (04)</a>
                                                </li>
                                                <li>
                                                    <a href="#"><i class="flaticon-arrow-button"></i>Marketing Plan (22)</a>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="sidebar__widget">
                                        <h4 class="sidebar__widget-title">Latest Posts</h4>
                                        <div class="sidebar__post-list">
                                            <div class="sidebar__post-item">
                                                <div class="sidebar__post-thumb">
                                                    <a href="blog-details.html"><img src="{{ asset('assets_rise/img/blog/sb_post01.jpg') }}" alt="Apexa" /></a>
                                                </div>
                                                <div class="sidebar__post-content">
                                                    <h5 class="title"><a href="blog-details.html">deno weuine easiure and praising</a></h5>
                                                    <span class="date"><i class="flaticon-time"></i>Sep 15, 2024</span>
                                                </div>
                                            </div>
                                            <div class="sidebar__post-item">
                                                <div class="sidebar__post-thumb">
                                                    <a href="blog-details.html"><img src="{{ asset('assets_rise/img/blog/sb_post02.jpg') }}" alt="Apexa" /></a>
                                                </div>
                                                <div class="sidebar__post-content">
                                                    <h5 class="title"><a href="blog-details.html">know how to pursue pleasure rationally</a></h5>
                                                    <span class="date"><i class="flaticon-time"></i>Sep 15, 2024</span>
                                                </div>
                                            </div>
                                            <div class="sidebar__post-item">
                                                <div class="sidebar__post-thumb">
                                                    <a href="blog-details.html"><img src="{{ asset('assets_rise/img/blog/sb_post03.jpg') }}" alt="Apexa" /></a>
                                                </div>
                                                <div class="sidebar__post-content">
                                                    <h5 class="title"><a href="blog-details.html">there anyone who loves</a></h5>
                                                    <span class="date"><i class="flaticon-time"></i>Sep 15, 2024</span>
                                                </div>
                                            </div>
                                            <div class="sidebar__post-item">
                                                <div class="sidebar__post-thumb">
                                                    <a href="blog-details.html"><img src="{{ asset('assets_rise/img/blog/sb_post04.jpg') }}" alt="Apexa" /></a>
                                                </div>
                                                <div class="sidebar__post-content">
                                                    <h5 class="title"><a href="blog-details.html">deno weuine easiure and praising</a></h5>
                                                    <span class="date"><i class="flaticon-time"></i>Sep 15, 2024</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="sidebar__widget">
                                        <h4 class="sidebar__widget-title">Tags</h4>
                                        <div class="sidebar__tag-list">
                                            <ul class="list-wrap">
                                                <li><a href="#">Finance</a></li>
                                                <li><a href="#">Data</a></li>
                                                <li><a href="#">Agency</a></li>
                                                <li><a href="#">Business</a></li>
                                                <li><a href="#">Corporate</a></li>
                                                <li><a href="#">Development</a></li>
                                                <li><a href="#">Consultancy</a></li>
                                            </ul>
                                        </div>
                                    </div>
                                </aside>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- blog-area-end --> 
        </main>
        <!-- main-area-end -->
        <!-- footer-area -->
        <footer>
            <div class="footer-area">
                <div class="footer-top">
                    <div class="container">
                        <div class="row">
                            <div class="col-xl-4 col-lg-4 col-md-6">
                                <div class="footer-widget">
                                    <div class="fw-logo mb-25">
                                        <a href="index.html"><img src="{{ asset('assets_rise/img/logo/logo.png') }}" alt="Apexa" /></a>
                                    </div>
                                    <div class="footer-content">
                                        <p>Felis consquat magnis fames sagittis ultrices plasodales porttitor quisque ultrice tempor turpis.</p>
                                        <div class="footer-social">
                                            <ul class="list-wrap">
                                                <li>
                                                    <a href="javascript:void(0)"><i class="fab fa-facebook-f"></i></a>
                                                </li>
                                                <li>
                                                    <a href="javascript:void(0)"><i class="fab fa-twitter"></i></a>
                                                </li>
                                                <li>
                                                    <a href="javascript:void(0)"><i class="fab fa-instagram"></i></a>
                                                </li>
                                                <li>
                                                    <a href="javascript:void(0)"><i class="fab fa-pinterest-p"></i></a>
                                                </li>
                                                <li>
                                                    <a href="javascript:void(0)"><i class="fab fa-youtube"></i></a>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-4 col-lg-4 col-md-6 col-sm-6">
                                <div class="footer-widget">
                                    <h4 class="fw-title">Information</h4>
                                    <div class="footer-info-list">
                                        <ul class="list-wrap">
                                            <li>
                                                <div class="icon">
                                                    <i class="flaticon-phone-call"></i>
                                                </div>
                                                <div class="content">
                                                    <a href="tel:09785606061">097856 06061</a>
                                                </div>
                                            </li>
                                            <li>
                                                <div class="icon">
                                                    <i class="flaticon-envelope"></i>
                                                </div>
                                                <div class="content">
                                                    <a href="mailto:info@risecivils.com">info@risecivils.com</a>
                                                </div>
                                            </li>
                                            <li>
                                                <div class="icon">
                                                    <i class="flaticon-pin"></i>
                                                </div>
                                                <div class="content">
                                                    <p>Under Triveni Puliya, 7A, Gangotri Nagar, Arjun Nagar, Jaipur, Rajasthan 302018</p>
                                                </div>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-4 col-lg-4 col-md-6 col-sm-6">
                                <div class="footer-widget">
                                    <h4 class="fw-title">Top Links</h4>
                                    <div class="footer-link-list">
                                        <ul class="list-wrap">
                                            <li>
                                                <div class="content">
                                                    <a href="/courses"> Courses
                                                    </a>
                                                </div>
                                            </li>
                                            <li>
                                                <div class="content">
                                                    <a href="/current-affairs">Current Affairs
                                                    </a>
                                                </div>
                                            </li>
                                            <li>
                                                <div class="content">
                                                    <a href="about-us.html">About Us
                                                    </a>
                                                </div>
                                            </li>
                                            <li>
                                                <div class="content">
                                                    <a href="contact-us.html">Contact Us
                                                    </a>
                                                </div>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div> 
                        </div>
                    </div>
                </div>
                <div class="footer-bottom">
                    <div class="container">
                        <div class="row align-items-center"> 
                            <div class="col-lg-12">
                                <div class="copyright-text text-center">
                                    <p>©2025 Brosis Technologies Team. All Rights Reserved.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="footer-shape">
                    <img class="dark-opacity" src="{{ asset('assets_rise/img/images/footer_shape01.png') }}" alt="Apexa" data-aos="fade-right" data-aos-delay="400" />
                    <img class="dark-opacity" src="{{ asset('assets_rise/img/images/footer_shape02.png') }}" alt="Apexa" data-aos="fade-left" data-aos-delay="400" />
                    <img src="{{ asset('assets_rise/img/images/footer_shape03.png') }}" alt="Apexa" data-parallax='{"x" : 100 , "y" : -100 }' />
                </div>
            </div>
        </footer>
        <!-- footer-area-end -->
        <!-- JS here -->
        <script src="{{ asset('assets_rise/js/vendor/jquery-3.6.0.min.js') }}"></script>
        <script src="{{ asset('assets_rise/js/bootstrap.bundle.min.js') }}"></script>
        <script src="{{ asset('assets_rise/js/jquery.magnific-popup.min.js') }}"></script>
        <script src="{{ asset('assets_rise/js/jquery.odometer.min.js') }}"></script>
        <script src="{{ asset('assets_rise/js/jquery.appear.js') }}"></script>
        <script src="{{ asset('assets_rise/js/gsap.js') }}"></script>
        <script src="{{ asset('assets_rise/js/ScrollTrigger.js') }}"></script>
        <script src="{{ asset('assets_rise/js/SplitText.js') }}"></script>
        <script src="{{ asset('assets_rise/js/gsap-animation.js') }}"></script>
        <script src="{{ asset('assets_rise/js/jquery.parallaxScroll.min.js') }}"></script>
        <script src="{{ asset('assets_rise/js/swiper-bundle.js') }}"></script>
        <script src="{{ asset('assets_rise/js/ajax-form.js') }}"></script>
        <script src="{{ asset('assets_rise/js/wow.min.js') }}"></script>
        <script src="{{ asset('assets_rise/js/aos.js') }}"></script>
        <script src="{{ asset('assets_rise/js/main.js') }}"></script>
        <script>
            function rangeSlide(value) {
                document.getElementById("rangeValue").innerHTML = value;
            }
        </script>
    </body>
</html>
